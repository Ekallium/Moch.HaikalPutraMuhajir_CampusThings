package Pyramid;

public class PyramidMain {
    public static void main(String[] args) {
        Pyramid pyramid = new Pyramid(12, 7.5);
        pyramid.printLuasAlas();
        pyramid.printVolume();
    }
}
